#include "../View/Headers/Texture.h"

Texture::Texture()
{}
