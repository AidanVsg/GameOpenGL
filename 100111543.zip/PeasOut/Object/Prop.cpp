#include "../Object/Headers/Prop.h"

Prop::Prop()
{
}
