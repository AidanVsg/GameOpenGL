#if !defined(_PROP_H)
#define _PROP_H

#include "../Object/Headers/Entity.h"

class Prop : public Entity {
public:
	Prop();
};

#endif  //_PROP_H
